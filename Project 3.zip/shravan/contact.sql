-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2017 at 12:49 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `shravan_proj`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `message` varchar(500) NOT NULL,
  `roc` varchar(30) NOT NULL,
  `time_stamp` timestamp NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `username`, `subject`, `email`, `message`, `roc`, `time_stamp`) VALUES
(1, 'anurag', 'New Form Submitted', 'anurag.beeram7@gmail.com', 'hii', 'Collaboration', '2017-05-01 22:38:55'),
(2, 'pablo', 'New Form Submitted', 'pablo@gmail.com', 'maal', 'Collaboration', '2017-05-01 22:39:44'),
(3, 'shravan', 'New Form Submitted', 'shravan@gmail.com', 'hiii', 'Job Offer', '2017-05-01 22:40:32'),
(4, 'naren', 'New Form Submitted', 'naren@gmail.com', 'random text', 'Job Offer', '2017-05-01 22:41:04'),
(5, 'saketh', 'New Form Submitted', 'saketh@gmail.com', 'random text', 'Job Offer', '2017-05-01 22:41:29'),
(6, 'sunil', 'New Form Submitted', 'sunil@yahoo.com', 'random text', 'Job Offer', '2017-05-01 22:43:15');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
