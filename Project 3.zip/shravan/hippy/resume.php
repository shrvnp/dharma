<!DOCTYPE html>
<html class="no-js" lang="en"> 
<head>


   <meta charset="utf-8">
   <title>Shravan Panicker</title>
   <meta name="description" content="">
   <meta name="author" content="">

   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


   <link rel="stylesheet" href="css/default.css">
   <link rel="stylesheet" href="css/layout.css">
   <link rel="stylesheet" href="css/media-queries.css">
   <link rel="stylesheet" href="css/magnific-popup.css">


   <script src="js/modernizr.js"></script>

   <link rel="shortcut icon" href="favicon.png" >

</head>      
<body>

  
   <header id="home">

      <nav id="nav-wrap">

         <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show navigation</a>
         <a class="mobile-btn" href="#" title="Hide navigation">Hide navigation</a>

         <ul id="nav" class="nav">
            <li><a class="smoothscroll" href="home.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li class="current"><a class="smoothscroll" href="resume.php">Resume</a></li>
            <li><a class="smoothscroll" href="contact.php">Contact</a></li>
         </ul> 

      </nav>
 
 <div class="row banner">
         <div class="banner-text">
            <h1 class="responsive-headline">I'm Shravan Panicker</h1>
            <h3>I'm a New York based graduate student, currently pursuing <span>Masters in Information Systems (Business Analytics). </span>Completed B.Tech in <span>Electrical and Electronic Engineering</span>.  
            </h3>
            <hr />
            
         </div>
      </div>
      </header>
   <section id="resume">

   
      <div class="row education">

         <div class="three columns header-col">
            <h1><span>Education</span></h1>
         </div>

         <div class="nine columns main-col">

            <div class="row item">

               <div class="twelve columns">

                  <h3>Marist College, Poughkeepsie, New York</h3>
                  <p class="info">Masters in Information systems <span>&bull;</span> <em class="date">May 2018 (expected)</p>

                  <p>
                 Currently pursuing the Masters in Information Systems Through study of the diverse subjects that affect the operation of information system within organizations, the Information System Management degree attempts to equip recipients to manage and deploy effectively in a computer system in a changing Information Age.
                  </p>

               </div>

            </div> 

            <div class="row item">

               <div class="twelve columns">

                  <h3>SRM University, Chennai, India</h3>
                  <p class="info">B.Tech in Elecetrical And Electronics Engineering <span>&bull;</span> <em class="date">May 2015</em></p>

                  <p>
                  Accquired the degree of bachelors in EEE on may 2015. Part of many mini projects during 8 semesters of study. My final Year project was called
                  Characterstics of PhotoVoltaic Module where we did the experiment called maximum power point tracking. Here we stepped up the solar power input of mere voltages to higher voltage yield.
                  </p>

               </div>

            </div> 

         </div> 

      </div> 

      


      
      <div class="row skill">

         <div class="three columns header-col">
            <h1><span>Skills</span></h1>
         </div>

         <div class="nine columns main-col">

            <p>SQL, MATLAB, PSPICE
            </p>
            <br>
            <br>
            <br>

 <div class="columns download">
                  <p>
                     <a href="sr.pdf" class="button" font color = "black"><i class="fa fa-download"></i>Download Resume</a>
                  </p>
               </div>
            

      </div> 

   </section> 


   

</body>

</html>