<!DOCTYPE html>
<html class="no-js" lang="en"> 
<head>


   <meta charset="utf-8">
   <title>Shravan Panicker</title>
   <meta name="description" content="">
   <meta name="author" content="">

   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">


   <link rel="stylesheet" href="css/default.css">
   <link rel="stylesheet" href="css/layout.css">
   <link rel="stylesheet" href="css/media-queries.css">
   <link rel="stylesheet" href="css/magnific-popup.css">


   <script src="js/modernizr.js"></script>

   <link rel="shortcut icon" href="favicon.png" >

</head>

<body>

  
   <header id="home">

      <nav id="nav-wrap">

         <a class="mobile-btn" href="#nav-wrap" title="Show navigation">Show navigation</a>
         <a class="mobile-btn" href="#" title="Hide navigation">Hide navigation</a>

         <ul id="nav" class="nav">
            <li><a href="index.php">Home</a></li>
            <li class="current"><a  href="about.php">About</a></li>
            <li><a  href="resume.php">Resume</a></li>
            <li><a  href="contact.php">Contact</a></li>
         </ul> 
      </nav> 

      <div class="row banner">
         <div class="banner-text">
            <h1 class="responsive-headline">I'm Shravan Panicker</h1>
            <h3>I'm a New York based graduate student, currently pursuing <span>Masters in Information Systems (Business Analytics). </span>Completed B.Tech in <span>Electrical and Electronic Engineering</span>.  
            </h3>
            <hr />
            
         </div>
      </div>

      

   </header>
   <section id="about">

      <div class="row">

         <div class="three columns">

            <img class="profile-pic"  src="spic.jpg" alt="img.pic" />

         </div>

         <div class="nine columns main-col">

            <h2>About Me</h2>

            <p>Hey!! I'm from India. Basically stayed for longer time in cities like Raipur, Bhilai and Chennai. I love been intoduced to new cultures,
            beliefs and food. Travelling to hill stations and regions I enjoyed the most. Reading novels, blogs and articles are my favourite past time 
            along with amateur dancing (hip hop and crumping) and doodling. 
            </p>

            

         </div> 

      </div>

   </section> 

            
</body>

</html>